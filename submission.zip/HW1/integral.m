function F = integral(f, t, r, a, b)

    F = int(f*t, r, a, b);

    
end